#include <iostream>
#include <string>

#include "NguoiSoHuu.h"
#include "SoHong.h"
#include "SoHongDatNN.h"
#include "SoHongDatO.h"

using namespace std;

void nhapGiayChungNhan(cSoHong* ds[], int& n);
void tinhTienThue(cSoHong* ds[], int n);
void timDatHetHan(cSoHong* ds[], int n);

int main()
{
	int n;
	cSoHong* dsGiayCN[50];

	nhapGiayChungNhan(dsGiayCN, n);
	tinhTienThue(dsGiayCN, n);
	timDatHetHan(dsGiayCN, n);

	return 0;
}

void nhapGiayChungNhan(cSoHong* ds[], int& n) {
	cout << "Nhap so luong giay chung nhan: ";
	cin >> n;
	int loai;
	for (int i = 0; i < n; i++) {
		cout << "Cap giay chung nhan Dat nong nghiep (1) hay dat o (2): ";
		cin >> loai;
		switch (loai) {
		case 1:
			ds[i] = new cSoHongDatNN;
			break;
		case 2:
			ds[i] = new cSoHongDatO;
			break;
		}

		ds[i]->Nhap();
	}
}

void tinhTienThue(cSoHong* ds[], int n) {
	double max = ds[0]->TinhTienThue();
	int iMax = 0;

	for (int i = 1; i < n; i++)
		if (ds[i]->TinhTienThue() > max) {
			max = ds[i]->TinhTienThue();
			iMax = i;
		}

	cout << "----------------------------------\n";
	ds[iMax]->Xuat();
}

void timDatHetHan(cSoHong* ds[], int n) {
	cout << "==================================\n";
	cout << "Danh sach giay chung nhan dat het han:\n";
	for (int i = 0; i < n; i++)
		if (ds[i]->getLoai() == 1)
			if (((cSoHongDatNN*)ds[i])->getThoiHan() < 2020) {
				cout << "----------------------------------\n";
				ds[i]->Xuat(); 
			}
}

