#include "NguoiSoHuu.h"

cNguoiSoHuu::cNguoiSoHuu() {
	this->HoTen = "";
	this->NamSinh = 2000;
	this->ID = "";
	this->DiaChi = "";
}

cNguoiSoHuu::cNguoiSoHuu(string HoTen, int NamSinh, string ID, string DiaChi) {
	this->HoTen = HoTen;
	this->NamSinh = NamSinh;
	this->ID = ID;
	this->DiaChi = DiaChi;
}

void cNguoiSoHuu::Nhap() {
	cout << "Ho ten nguoi so huu: ";
	cin >> HoTen;
	cout << "Nam sinh nguoi so huu: ";
	cin >> NamSinh;
	cout << "So CMND: ";
	cin >> ID;
	cout << "Dia chi: ";
	cin >> DiaChi;
}

void cNguoiSoHuu::Xuat() {
	cout << "Ho ten: " << HoTen;
	cout << " Nam sinh: " << NamSinh;
	cout << " So CMND: " << ID;
	cout << " Dia chi: " << DiaChi << endl;
}
