#pragma once
#include <iostream>
using namespace std;

class cNguoiSoHuu
{
private:
	string HoTen;
	int NamSinh;
	string ID;
	string DiaChi;

public:
	cNguoiSoHuu();
	cNguoiSoHuu(string, int, string, string);
	void Nhap();
	void Xuat();
};

