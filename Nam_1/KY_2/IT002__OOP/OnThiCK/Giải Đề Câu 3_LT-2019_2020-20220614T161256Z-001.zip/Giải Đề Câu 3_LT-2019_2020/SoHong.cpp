#include "SoHong.h"

cSoHong::cSoHong() {
	this->SoGiayCN = "";
	this->SoNguoiSoHuu = 0;
	this->SoThua = 0;
	this->SoToBanDo = 0;
	this->DiaChi = "";
	this->DienTich = 0;
	this->NgayCap = "";
	this->DonGiaThue = 0;
}

cSoHong::cSoHong(string SoGiayCN, int SoNguoiSoHuu, cNguoiSoHuu* dsNguoiSoHuu, int SoThua, int SoToBanDo, string DiaChi, int DienTich, string NgayCap, int DonGiaThue) {
	this->SoGiayCN = SoGiayCN;
	this->SoNguoiSoHuu = SoNguoiSoHuu;
	this->dsNguoiSoHuu = dsNguoiSoHuu;
	this->SoThua = SoThua;
	this->SoToBanDo = SoToBanDo;
	this->DiaChi = DiaChi;
	this->DienTich = DienTich;
	this->NgayCap = NgayCap;
	this->DonGiaThue = DonGiaThue;
}

void cSoHong::Nhap()
{
	cout << "Nhap so luong nguoi dung ten so hong: ";
	cin >> SoNguoiSoHuu;
	dsNguoiSoHuu = new cNguoiSoHuu[SoNguoiSoHuu];
	for (int i = 0; i <SoNguoiSoHuu; i++)
	{
		cout << "Nhap thong tin nguoi so huu  " << endl;
		dsNguoiSoHuu[i].Nhap();
	}
	cout << "Nhap so giay chung nhan: ";
	cin >> SoGiayCN;
	cout << "Nhap so thua: ";
	cin >> SoThua;
	cout << "Nhap so to ban do: ";
	cin >>SoToBanDo;
	cout << "Nhap dia chi thua dat: ";
	cin >> DiaChi;
	cout << "Nhap dien tich: ";
	cin >> DienTich;
	cout << "Nhap ngay cap giay chung nhan: ";
	cin >> NgayCap;
	cout << "Nhap don gia thue: ";
	cin >> DonGiaThue;
}

void cSoHong::Xuat()
{
	cout << "So giay chung nhan: " << SoGiayCN << endl;
	for (int i = 0; i <SoNguoiSoHuu; i++)
	{
		dsNguoiSoHuu[i].Xuat();
	}
	cout << "So thua dat: " << SoThua << endl;
	cout << "So to ban do: " << SoToBanDo << endl;
	cout << "Dia chi thua dat: " << DiaChi << endl;
	cout << "Dien tich thua dat: " << DienTich << endl;
	cout << "Ngay cap: " << NgayCap << endl;
	cout << "Don gia thue: " << DonGiaThue << endl;
}

double cSoHong::TinhTienThue()
{
	return DienTich * DonGiaThue;
}
