#pragma once
#include "NguoiSoHuu.h"
#include <iostream>
using namespace std;

class cSoHong
{
protected:
	string SoGiayCN;
	int SoNguoiSoHuu;
	cNguoiSoHuu* dsNguoiSoHuu;
	int SoThua;
	int SoToBanDo;
	string DiaChi;
	int DienTich;
	string NgayCap;
	int DonGiaThue;

public:
	cSoHong();
	cSoHong(string SoGiayCN, int SoNguoiSoHuu, cNguoiSoHuu* dsNguoiSoHuu, int SoThua, int SoToBanDo, string DiaChi, int DienTich, string NgayCap, int DonGiaThue);
	virtual void Nhap();
	virtual void Xuat();
	virtual double TinhTienThue();
	virtual int getLoai() = 0;
};
