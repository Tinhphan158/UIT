#include "SoHongDatNN.h"

int cSoHongDatNN::getThoiHan()
{
	return this->ThoiHan;

}
void cSoHongDatNN::Nhap()
{
	cSoHong::Nhap();
	cout << "Nhap thoi han su dung: ";
	cin >> ThoiHan;
}
void cSoHongDatNN::Xuat()
{
	cSoHong::Xuat();
	cout << "Thoi han su dung: " << ThoiHan << endl;
	cout << "Tien thue phai dong: " << DonGiaThue * DienTich << endl;
}
int cSoHongDatNN::getLoai()
{
	return 1;
}
