#pragma once
#include "SoHong.h"

class cSoHongDatNN : public cSoHong
{
protected:
	int ThoiHan;
public:
	void Nhap();
	void Xuat();
	int getLoai();
	int getThoiHan();
};

