#include "SoHongDatO.h"

void cSoHongDatO::Xuat()
{
	cSoHong::Xuat();
	cout << "Tien thue phai dong: " << DonGiaThue * DienTich << endl;
}
int cSoHongDatO::getLoai()
{
	return 2;
}
