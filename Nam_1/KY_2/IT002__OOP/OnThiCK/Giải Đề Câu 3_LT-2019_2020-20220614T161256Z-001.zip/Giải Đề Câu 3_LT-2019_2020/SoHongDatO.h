#pragma once
#include "SoHong.h"

class cSoHongDatO : public cSoHong
{
public:
	void Xuat();
	int getLoai();
};
